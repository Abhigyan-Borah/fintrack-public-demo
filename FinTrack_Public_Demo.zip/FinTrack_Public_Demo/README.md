# FinTrack — Public Demo

A public-facing NiceGUI demo of the Personal Finance Analyzer. It contains **fictional sample records only** and is intentionally separated from the personal/local project.

## Safety boundary

- The app loads and writes only `demo_data/transactions.json` and `demo_data/budget.json`.
- These files contain invented demo data, not personal finance records.
- Do **not** copy your real `transactions.json`, `budget.json`, exports, or backups into this folder or its Git repository.
- This version has no login. The demo dataset is shared: visitors can add/delete transactions or change budgets, and changes may be visible to other visitors. Demo data can reset when the service is redeployed or restarted. Never enter real personal or financial information.
- Do not use this public demo for real budgeting. This package is for showcasing/testing only.

## Run locally

Requires Python 3.10+. From this folder:

```bash
python -m venv .venv
```

Windows PowerShell:
```powershell
.venv\Scripts\Activate.ps1
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Install and start:
```bash
python -m pip install -r requirements.txt
python gui.py
```

Open <http://127.0.0.1:8080>. All local changes are limited to the included demo JSON files.

## Publish with Render

This folder includes `render.yaml` as a deployment blueprint. Render's public web services must listen on `0.0.0.0` and the port supplied in `PORT`; this app is configured for that. Render provides a public `onrender.com` URL and HTTPS at its edge. See [Render's official web-service documentation](https://render.com/docs/web-services).

1. Create a **new, separate GitHub repository** for this folder, e.g. `fintrack-public-demo`. Do not push your personal project folder or personal JSON files.
2. Upload only the contents of this folder to that repository. Inspect the repository file list before publishing. It should include `gui.py`, `finance_manager.py`, `requirements.txt`, `render.yaml`, `.gitignore`, `README.md`, and the two fictional files under `demo_data/`.
3. In Render, choose **New → Blueprint** and connect that demo-only repository, or create a Web Service with build command `pip install -r requirements.txt` and start command `python gui.py`.
4. Wait for deployment, then open the public `https://<service-name>.onrender.com` URL shown by Render.
5. Test the live page using only the fictional demo records. Confirm that the Overview, Transactions, search/delete, and Budgets pages behave as expected.

### Important deployment note

A public URL means anyone who has the URL can visit the app. HTTPS protects traffic in transit; it does not add login or prevent visitors from editing this shared demo dataset. Keep this demo dataset fictional. If you later want separate data for every visitor, add per-session isolation and appropriate server-side controls before publishing that version.

## Files

- `gui.py` — NiceGUI interface and Render-compatible server configuration.
- `finance_manager.py` — finance calculations and JSON persistence.
- `demo_data/transactions.json` — fictional transactions only.
- `demo_data/budget.json` — fictional monthly budgets only.
- `render.yaml` — Render deployment blueprint.
